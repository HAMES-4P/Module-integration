#ifndef BSW_ETC_MY_STDIO_H_
#define BSW_ETC_MY_STDIO_H_

extern void Init_Mystdio(void);
extern void my_puts(const char *str);
extern int my_printf(const char *format, ...);
extern void my_scanf(const char *fmt, ...);

#endif /* BSW_ETC_MY_STDIO_H_ */
